#include <strings.h>
